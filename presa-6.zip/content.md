# Promotion Case — Content Source

> This is the **editable source of truth** for the deck.
> Replace every `[XX]` and `[bracketed]` placeholder with real values, then ask
> corporate AI to "update the HTML deck (Promotion Case.html) to match content.md".
> Project names are kept generic on purpose: **Project1 / Project2 / Project3 / Audit1**.
> Three-question coverage is tagged inline: `#role-impact`, `#last-3-years`, `#beyond-role`.

---

## Speaker / framing
- Name: **[Your Name]**
- Title today: **Senior Engineer & Architect**
- Tenure: **10 years** in the organization
- Domain: **Trading Controls**
- Audience: **[10 engineering managers]**
- Length: **~7 minutes**
- Date: **[Date]**

---

## SLIDE 1 — Title (thesis)
- Eyebrow: `PROMOTION CASE · TRADING CONTROLS`
- Thesis (one line):
  **"I take a system, make it run itself, then reach higher — turning my work into the domain's standard."**
- Subline: Senior Engineer & Architect · 10 years · Trading Controls
- Footer: [Your Name] · [Date]

## SLIDE 2 — Who I am
- Line: **"I'm a senior engineer & architect of systems such as:"**
- Three screenshot blocks (drag images into the slots in the deck):
  - **Project1** — Constraints registry
  - **Project2** — Strategy management
  - **Project3** — Stack unification

---
## How I'm being evaluated (rubric — keep the deck aligned to this)
**Role & business impact** — role described transparently & clearly · strong ownership of applications · understands business priorities AND links app ↔ priorities · thinks like a leader.
**Achievements** — measurable impact on business or technology strategy · leading complex initiatives.
**Leadership** — demonstrates leadership, mentoring, cross-team influence & beyond the domain · clear link of leadership to change beyond the role.
---

## SLIDE 2 — Who am I? + the pattern
Large title **"Who am I?"** at top. Two columns. Left — three points about me:
1. **Senior engineer & architect**
2. **Owner of several projects**
3. **I build applications by the same pattern** — a connector **arrow** points from this point into the pseudocode on the right.
Right — `the_pattern.pseudo` code block (the repeatable loop), with Altitude caption: **My application → My domain → Beyond my domain.**

```
while (!everyoneOnboarded) {          // until it's the standard
    gap = findGap(myDomain);          // spot what's missing
    solution = designSolution(gap);
    selfManaged = optimize(solution); // make it run itself
    everyoneOnboarded = onboardSystems();
}
def optimize(solution) {
    designArchitecture();
    developSolution();
    defineMonitoring();
}
```

## STRUCTURE — three projects × three lenses
**Slide order:** Title → Who I am → **Overview (focus P1)** → Project1 ×3 → **Overview (focus P1)** → **Overview (focus P2, frame slides P1→P2)** → Project2 ×3 → **Overview (focus P2)** → **Overview (focus P3, frame slides P2→P3)** → Project3 ×3 → Closing.
Each project junction uses a double overview hub: the first focuses the project just finished (the page shrinks back into its tile), the second focuses the next project — and the highlight **frame slides** from one tile to the next. Then the next project page grows out of its tile.
Each project is revealed from three angles: **Scope of role · Achievements · Leadership**.
(Audit1 and the cloud-first migration are folded into Project1, their natural home — move them if you prefer.)

## SLIDE 4 — Project1 · Scope of role  #role-impact
**Visual metaphor: a reference standard off the execution path.** Strategies (left, each with its own `circuitBreaker()`) run **straight to the TRADING VENUE** (right; classical building icon — roof + three columns). The **CONSTRAINTS REGISTRY** (my project) **stands apart, above the path** — strategies query it (dashed "read limit values") for their limits. It is the single source of truth, not an inline gate.
- I own the **org-wide standard** for trading-strategy constraints.
- Caption: *Strategies run straight to the venue — but they all read their limits from one place: my registry, the single source of truth that stands apart. One standard, ~50 systems, the standard auditors trust.*

## SLIDE 5 — Project1 · Achievements  #achievements
- Now the **single standard** across the org for constraint management.
- **Auditors** go to my application to verify compliance.
- Also delivered **Audit1** — algorithm identification — rolled out **org-wide**.

## SLIDE 6 — Project1 · Leadership  #leadership
- Drove adoption across **~50 teams** by **influence, not mandate**.
- Engineered it to be **self-sustaining** so adoption scaled without me.
- **First in the domain** to migrate to **cloud infrastructure** — set the path others follow.

## SLIDE 7 — Project2 · Scope of role  #role-impact
**Visual metaphor: CLI chaos → one GUI (before / after).** Left: a messy pile of overlapping terminal windows (managing strategies by hand across many SSH sessions). Arrow "I built". Right: a single clean app window — **drop your real Strategy Manager GUI screenshot into the slot** (id `p2-gui`).
- Expanded my scope by closing a **domain-wide gap**.
- Caption: *Strategies were wrangled across dozens of CLI sessions. I built the one GUI that became the domain standard — [1,500] strategies, one control surface.*

## SLIDE 8 — Project2 · Achievements  #achievements
- A GUI that became the **standard** for managing strategies in the domain.
- `[1,500]` strategies managed through it.
- `[Cut operational risk / errors by XX%]` versus the old CLI.

## SLIDE 9 — Project2 · Leadership  #leadership
- **Initiative beyond assigned work**: spotted the gap, made the case, delivered.
- Onboarded teams onto the new control surface.
- Set the bar for **how strategy management is done** across the domain.

## SLIDE 10 — Project3 · Scope of role  #role-impact
- Role grew from architect to **cross-domain change driver**.
- Decommissioning **Project3**, unifying teams onto the **standard stack**.
- Orchestrating migration of **[10] complex downstream systems** — reaches **beyond my domain**.

## SLIDE 11 — Project3 · Achievements  #achievements
- **[10] complex downstream systems** migrating off Project3.
- Cutting **fragmentation** across the domain's application stack.
- `[Retiring XX legacy stacks / saving XX maintenance]`.

## SLIDE 12 — Project3 · Leadership  #leadership
- **Mentoring** `[N engineers]` and guiding downstreams on architecture & adoption. (Fill in real numbers — the rubric weights mentoring.)
- **Cross-team influence** without formal authority.
- Leadership that reaches **beyond my role and beyond my own domain**.

## SLIDE 17 — Summary (the case in three)
Dark finale. Eyebrow "In summary", then three rows (mapping to the deck's lenses):
- **Scope of role** → Project1 · Project2 · Project3 (chips)
- **Achievements** → Measurable impact
- **Leadership** → Driver of change in a cross-domain area
Footer: [Your Name] · Trading Controls.
