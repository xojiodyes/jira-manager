# Production Support Proposal — copy

> Source of truth for slide text. Edit here, then ask me to **"sync content.md to the deck"**.
> Only substantive copy — slide chrome (tags, version numbers, footers, slide counts) lives in the HTML.

---

## Slide 1 — Cover

- **Title**: Distributed production **support.**
- **Subtitle**: A proposal to move on-call from a small central team into the engineering teams that build the applications.

---

## Slide 2 — Three perspectives on one incident

- **Title**: One incident. **Three different problems.**

### Business
- **Take**: A tech issue blocking me from generating revenue.
- **Priority list**:
  - Q3 revenue target
  - **Reporting tool down** — *blocker* ← the incident
  - Customer launches
  - Pipeline review

### Support
- **Take**: One of many problems, too little context, can't fix myself.
- **Priority list**:
  - INC-4388 · analytics
  - INC-4389 · billing
  - INC-4390 · auth
  - INC-4391 · search
  - **INC-4392 · reporting** — *1 of 42* ← the incident
  - INC-4393 · CRM
  - INC-4394 · data export
  - *+ 35 more open*

### Engineers
- **Take**: Annoying Teams conversations that pull me off development.
- **Priority list**:
  - Feature: payment v2
  - Feature: search rebuild
  - **Support ping · reporting** — *interruption* ← the incident
  - Code reviews
  - Sprint planning

---

## Slide 3 — Coverage ratio

- **Title**: 60 applications. **5 supporters.**
- **Lead**: Each supporter holds context for roughly 12 applications they did not build. When everything is everyone's responsibility, nothing is anyone's priority.

---

## Slide 4 — The Operation Cell

- **Title**: The **Operation Cell.**
- **Lead**: Engineers and the supporter role merge into a single team. The cell owns its applications end to end — building, watching, fixing.

### Cell members (left visual)
- Developer
- Developer
- **Dev Lead** (highlighted, badge "owns it")
- Developer
- Prod Support

### Properties (right column)
1. **One queue, one owner.**
   Incidents land with the team that built the system — not with strangers.
2. **The fix lives where the code lives.**
   The engineer triaging can merge. No handoffs, no re-explaining.
3. **The system is self-improvment**
   *<empty>*

---

## Slide 5 — Expected outcomes

- **Title**: Knowledge, ownership, and feedback in the same hands.

1. **Fixes delivers fast**
   The engineer triaging the incident is the engineer who can merge the fix. No handoffs, no waiting for context to free up.
2. **The system improves, not just survives**
   When engineers carry their own production pain, reliability work earns a regular line in the roadmap rather than competing with features.
3. **Metric based approach**
   Improved tooling allows to capture metrics and enchance approach.

---

## Slide 6 — Rollout

- **Title**: A phased rollout + metric based apporach

### Timeline
1. **Month 1–2 — Pilot with 1 operation cell.**
   Pick teams whose engineers already operate close to prod. Build the playbook with them, not for them.
2. **Month 3–4 — Work in parallel with existing support model**
   Support team rebuilds itself around enablement: dashboards, alerts, on-call docs every team can pick up.
3. **Month 5–7 — Roll out new model**
   *<empty>*
4. **Month 8+ — Steady state.**
   Every app has named owners on rotation. Support team focuses on platform reliability and incident leadership.

---

## Slide 7 — The ask

- **Title**: Three asks of leadership.

1. **Air cover with engineering managers.**
   A clear signal from leadership that on-call rotation is expected work, not extra work — and that reliability time belongs in the roadmap.
2. **Permission to protect roughly 15% capacity.**
   Each team budgets one engineer-week per rotation for production support. Leadership defends that allocation against feature pressure.
3. **A standing review each quarter.**
   Thirty minutes per quarter to review incident trends, fix-shipped rates, and rollout status. The forum for course correction.

---

## Slide 8 — Summary

- **Title**: In summary.

- **Problem** — Five supporters cannot reasonably cover sixty applications. Every week incidents outpace fixes, and three teams feel the strain.
- **Proposal** — A weekly on-call rotation inside each engineering team, with the central support team transitioning to platform and enablement work.
- **Ask** — Leadership air cover, protected capacity of roughly 15% per team, and a quarterly review forum to keep the rollout on track.

- **Closing**: **Discussion next.** · Questions · concerns · what we have missed
