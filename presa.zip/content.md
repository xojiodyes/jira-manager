# Promotion Case — Content Source

> This is the **editable source of truth** for the deck.
> Replace every `[XX]` and `[bracketed]` placeholder with real values, then ask
> corporate AI to "update the HTML deck (Promotion Case.html) to match content.md".
> Project names are kept generic on purpose: **Project1 / Project2 / Project3 / Audit1**.
> Three-question coverage is tagged inline: `#role-impact`, `#last-3-years`, `#beyond-role`.

---

## Speaker / framing
- Name: **[Your Name]**
- Title today: **Senior Engineer & Architect**
- Tenure: **10 years** in the organization
- Domain: **Trading Controls**
- Audience: **[10 engineering managers]**
- Length: **~7 minutes**
- Date: **[Date]**

---

## SLIDE 1 — Title (thesis)
- Eyebrow: `PROMOTION CASE · TRADING CONTROLS`
- Thesis (one line):
  **"I take a system, make it run itself, then reach higher — turning my work into the domain's standard."**
- Subline: Senior Engineer & Architect · 10 years · Trading Controls
- Footer: [Your Name] · [Date]

## SLIDE 2 — My operating model (the mindset)
The repeatable loop behind everything below:
1. **Build** — design and ship the system.
2. **Make it self-sustaining** — automate it so it runs without me.
3. **Free capacity** — and ask my manager to expand my scope.
4. **Reach higher** — every cycle operates at a higher altitude.

Altitude ladder: **My application → My domain → Beyond my domain.**

## SLIDE 3 — Role & impact of the role  #role-impact
- What the role *was*: build and own applications.
- What the role *became*: define how the **Trading Controls** domain operates.
- I don't just write senior-level code — I set the standards others build and are audited against.

## SLIDE 4 — Flagship: Project1, the org-wide standard  #role-impact
**Project1 — the constraints registry for trading strategies.**
- Designed the architecture from scratch.
- Rolled it out across **~50 complex systems / teams**.
- Now the **single standard** across the whole organization.
- When auditors arrive, they go to **my application** to verify compliance of constraint management for trading algorithms.
- Headline stats: `50 systems` · `1 standard` · `auditors' source of truth`

---
### SECTION — Achievements, last 3 years  #last-3-years
---

## SLIDE 5 — Project2: the strategy-management standard  #last-3-years
- Noticed strategies were managed from the **command line**.
- Designed and built a **GUI** for it.
- Now the **standard way to manage strategies** in the domain.
- Headline stat: `[1,500]` strategies managed through it.

## SLIDE 6 — Audit1: algo identification, org-wide  #last-3-years #role-impact
- Delivered the solution for **Audit1** — identification of trading algorithms.
- Rolled out **across the whole organization**.
- Headline stat: `org-wide` adoption · `[XX]` systems covered.

## SLIDE 7 — Cloud-first in the domain  #last-3-years
- **First in the domain** to migrate an application to **cloud infrastructure**.
- Set the migration path the rest of the domain now follows.
- Headline stat: `1st in domain` · `[XX]%` cost / reliability improvement.

## SLIDE 8 — Beyond the role: domain & cross-domain change  #beyond-role
**Project3 decommission & stack unification.**
- Driving migration of **[10] complex downstream systems** off Project3 onto the domain's **standard stack**.
- Role here is bigger than "engineer": **architect + change driver** across teams.
- Not a PM — **the driver of change**: I help downstreams with architecture and adoption.
- This is **domain-level work — and reaches beyond my own domain.**
- Headline stat: `10 systems` · `cross-domain`

## SLIDE 9 — The three questions, answered
| Question | My answer |
|---|---|
| **Role & impact** | I set the org-wide standard others are **audited against** (Project1). |
| **Last 3 years** | Strategy-management standard (Project2), Audit1 org-wide, **cloud-first** in the domain. |
| **Beyond the role** | **Driving** cross-domain stack unification & Project3 decom. |

## SLIDE 10 — Closing (the case)
- One line: **"I already operate at the level of the domain — not just at senior level."**
- The pattern: every system I touch becomes the standard, then I reach higher.
- What's next: **[the scope / mandate you're asking for]**.
- Footer: [Your Name] · Trading Controls
